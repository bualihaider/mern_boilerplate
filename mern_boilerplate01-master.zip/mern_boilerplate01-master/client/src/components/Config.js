//SERVER ROUTES
export const USER_SERVER = '/api/users';
